
<?php 
include('../dbcon.php');

?>	

<?php /** @noinspection MultiAssignmentUsageInspection */

use Shuchkin\SimpleXLSX;

ini_set('error_reporting', E_ALL);
ini_set('display_errors', true);

require_once __DIR__.'/../src/SimpleXLSX.php';

echo '<h1>Read several sheets</h1>';
if ($xlsx = SimpleXLSX::parse('Book1.xlsx')) {
    echo '<pre>'.print_r($xlsx->sheetNames(), true).'</pre>';

    echo '<table cellpadding="10">
	<tr><td valign="top">';

    // output worksheet 1 (index = 0)

    $dim = $xlsx->dimension();
    $num_cols = $dim[0];
    $num_rows = $dim[1];

    echo '<h2>'.$xlsx->sheetName(0).'</h2>';
    echo '<table border=1>';
    foreach ($xlsx->rows() as $r) {
        echo '<tr>';
        for ($i = 0; $i < $num_cols; $i ++) {
            echo '<td>' . ( ! empty(	[ $i ]) ? $r[ $i ] : '&nbsp;' ) . '</td>';
        }
		
		$book_title=$r[3];
		$category_id="";
		$author=$r[2];
		$book_copies=1;
		$book_pub="OBC";// its should be sc st or obc as its not there
		$publisher_name=$r[7];
		$isbn=$r[1];
		$Book_type = "";
		$copyright_year=$r[8];
		/* $date_receive=$_POST['date_receive']; */
		/* $date_added=$_POST['date_added']; */
		$status="OK";

//echo "<script> alert('$isbn');</script>";
		mysqli_query($conn,"insert into book (book_title,category_id,author,book_copies,book_pub,publisher_name,isbn,copyright_year,date_added,status,category)
		values('$book_title','$category_id','$author','$book_copies','$book_pub','$publisher_name','$isbn','$copyright_year',NOW(),'$status','$category_id')")or die(mysqli_error());
			echo "<script> alert('book added');</script>";



        echo '</tr>';
    }
    echo '</table>';

    echo '</td><td valign="top">';

    // output worsheet 2 (index = 1)

    $dim = $xlsx->dimension(1);
    $num_cols = $dim[0];
    $num_rows = $dim[1];

    echo '<h2>'.$xlsx->sheetName(1).'</h2>';
    echo '<table border=1>';
    foreach ($xlsx->rows(1) as $r) {
        echo '<tr>';
        for ($i = 0; $i < $num_cols; $i ++) {
            echo '<td>' . ( ! empty($r[ $i ]) ? $r[ $i ] : '&nbsp;' ) . '</td>';
        }
        echo '</tr>';
    }
    echo '</table>';

    echo '</td></tr></table>';
} else {
    echo SimpleXLSX::parseError();
}
